﻿[MD/0.1]
Last-Modified: 1182879012
Visible: true
Format: markdown
Created: 1181411898
Edited-Number: 0
Type: PinkyBlog/StaticEntry

（この部分には、blogについての解説を書いてください）
.