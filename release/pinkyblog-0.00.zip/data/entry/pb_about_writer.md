[MD/0.1]
Last-Modified: 1182878994
Visible: true
Format: markdown
Created: 1182335316
Edited-Number: 0
Type: PinkyBlog/StaticEntry

（この部分には、あなたについての自己紹介文や解説を書いてください）
.