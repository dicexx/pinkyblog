﻿[MD/0.1]
Last-Modified: 1186754393
Visible: true
Format: markdown
Created: 1181489769
Edited-Number: 0
Type: PinkyBlog/StaticEntry

Pinky:blogをダウンロードいただきありがとうございます。この画面（トップページ）が正しく表示できているなら、次は管理者モードにログインしてみてください。URLの後に`/login`を付ける（`blog.cgi/login`のように入力する）と、パスワードの入力画面が表示されます。

なお、この文章は管理者モードから編集可能です。
.