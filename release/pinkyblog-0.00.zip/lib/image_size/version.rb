module Imagesize #:nodoc:
  module VERSION #:nodoc:
    MAJOR = 0
    MINOR = 1
    TINY  = 1

    STRING = [MAJOR, MINOR, TINY].join('.')
  end
end
