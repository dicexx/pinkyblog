#-----------------------------------------------------------
# Pinky:blog
#
# Author:   Dice
# License:  NYSL 0.9982 (http://www.kmonos.net/nysl/)
# URL:      http://scl.littlestar.jp/pinkyblog/
#-----------------------------------------------------------
require 'pinkyblog/core'
