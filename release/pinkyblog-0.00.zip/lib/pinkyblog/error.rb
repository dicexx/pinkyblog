# 例外クラス（あまり使う機会はない）

module PinkyBlog
	class Error < StandardError
	end
end
