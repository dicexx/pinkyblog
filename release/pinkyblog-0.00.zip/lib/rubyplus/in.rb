class Object
	def in?(container)
		container.include?(self)
	end
end
