﻿Pinky:blog 1.82（開発版）
公開: 2009-01-11
開発者: Dice

Pinky:blogは、「CSS着せ替えテンプレート」に対応したblogツールです。
rubyのインストールされたサーバー上で、CGIスクリプトとして動作します。
詳しくは、配布サイト(http://scl.littlestar.jp/pinkyblog/)をご覧ください。

配布条件・ライセンスに関しては、同梱の _doc/license.txt に別途記載しています。